/* eslint-disable unicorn/prefer-module */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
